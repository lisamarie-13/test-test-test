# Requirement: Order Checkout Journey — Price Display Broken and Form Clears on Validation Error

**Reporter:** SLICC Agent  
**Work Type:** Bug  
**Priority:** Critical  
**Assignee:** (unassigned)

## Problem Statement
The Order Checkout journey on Glitchcraft Margarita Labs has two critical bugs that prevent customers from completing their order: (1) the "Build Your Own Margarita" price display always shows "$0.00" regardless of selected options, so customers cannot see what they will pay, and (2) when submitting the checkout form with an invalid zip code, all form fields are cleared — forcing the customer to re-enter everything from scratch.

## Impact
- Bounce rate: 72% (vs site average of 30%)
- Error rate: 15%
- CSAT score: 2.0/5
- Affected pageviews (estimated): 114,700/month (11,470,000 real views at 100x sampling)
- Customer verbatim: "I filled out my entire address and when it said my zip code was wrong, it cleared EVERYTHING. I had to start over three times before I gave up."

## Steps to Reproduce

### Bug #1: Price Never Updates
1. Navigate to http://localhost:5710/preview/workspace/skills/ux-research-agent/site/index.html
2. Click "Order" in the navigation bar
3. In the "Build Your Own Margarita" section, select "Blanco Tequila (+$14)" as the Base Spirit
4. Select "Charred Jalapeño Syrup (+$4)" as the Mixer
5. Select "Charcoal Salt Rim (+$3)" as the Extra
6. **Observe:** The "Your Total" display shows "$0.00" — expected "$21.00"

### Bug #2: Form Clears on Validation Error
1. From the Build Your Own page, click "Continue to Checkout"
2. Fill in the checkout form:
   - Full Name: Jane Doe
   - Email: jane@example.com
   - Street Address: 123 Rainey Street
   - City: Austin
   - Zip Code: ABCDE (non-numeric, triggers validation)
   - Credit Card: 4242 4242 4242 4242
   - Expiry: 12/27
   - CVC: 123
3. Click "Place Order"
4. **Observe:** The "Invalid zip code format" error appears, but ALL form fields are now empty — the user must re-enter every field
5. **Observe:** A JavaScript error is thrown: `TypeError: Cannot read properties of undefined (reading 'validate')` from the line `undefined.validate()`

## Technical Details
- LCP: 5721ms (poor, threshold: 2500ms)
- CLS: 0.451 (poor, threshold: 0.1)
- INP: 478ms (needs-improvement, threshold: 200ms)
- JS Errors:
  - `TypeError: Cannot read properties of undefined (reading 'validate')` — thrown in `submitOrder()` at line 1085 after zip validation fails
  - Root cause for Bug #1: `updatePrice()` sets `var total = 0` and never adds the parsed select values (`parseInt(base||0) + parseInt(mixer||0) + parseInt(extra||0)`)
  - Root cause for Bug #2: `submitOrder()` iterates over all `#order-checkout input` elements and sets `.value = ''` before returning on validation failure
- Affected devices: both desktop and mobile
- Severity Score: 53.6 (Critical)

## Acceptance Criteria
- [ ] `updatePrice()` correctly sums the selected values from Base Spirit, Mixer, and Extras dropdowns and displays the total (e.g., "$21.00" for Blanco + Jalapeño Syrup + Charcoal Salt Rim)
- [ ] Price display updates reactively as the user changes any dropdown selection
- [ ] When checkout form validation fails (e.g., invalid zip), only the invalid field is highlighted — all other field values are preserved
- [ ] The `undefined.validate()` call is removed or replaced with valid validation logic; no JS errors are thrown during form submission
- [ ] Zip code validation error message appears inline next to the zip field with clear guidance (e.g., "Please enter a 5-digit zip code")
- [ ] After correcting the zip code, the user can successfully submit without re-entering any other fields
- [ ] Web Vitals are improved: LCP < 2500ms, CLS < 0.1, INP < 200ms

## Screenshots
- `/shared/screenshots/01-homepage.png` — Homepage before navigation
- `/shared/screenshots/02-order-page-initial.png` — Order page with Build Your Own form (no selections)
- `/shared/screenshots/03-price-bug-zero-dollars.png` — Selections made (Blanco Tequila, Jalapeño Syrup, Charcoal Salt Rim) but price shows $0.00
- `/shared/screenshots/04-checkout-form-filled.png` — Checkout form fully filled with test data before submission
- `/shared/screenshots/05-checkout-form-cleared-bug.png` — After clicking Place Order: "Invalid zip code format" error visible, all form fields emptied

## Loom Recording
(Loom not available in this environment — screenshots provided as substitute)
