# E2E Walkthrough Log: Order Checkout Journey

**Agent:** ux-e2e-checkout-scoop  
**Date:** 2026-05-17  
**Target:** Glitchcraft Margarita Labs — Order Checkout Journey  
**URL:** http://localhost:5710/preview/workspace/skills/ux-research-agent/site/index.html

## Steps Performed

### 1. Opened the site
- Used `playwright-cli open` to navigate to the site URL
- Captured tab ID: `A04599362DD245CA9DEE65AFB5BC2DA4`

### 2. Screenshot homepage
- Saved: `/shared/screenshots/01-homepage.png`
- Homepage loaded correctly with navigation, hero section, featured drinks

### 3. Navigated to Order page
- Used `playwright-cli eval` to call `showPage('order')` (SPA navigation)
- Page showed "Build Your Own Margarita" with three dropdowns and $0.00 price display

### 4. Screenshot initial order form
- Saved: `/shared/screenshots/02-order-page-initial.png`
- All dropdowns at default "Select..." state, price at $0.00

### 5. Selected dropdown options
- Base Spirit: Blanco Tequila (+$14) — value "14"
- Mixer: Charred Jalapeño Syrup (+$4) — value "4"
- Extras: Charcoal Salt Rim (+$3) — value "3"
- Used `eval` to set values and dispatch change events

### 6. Documented Bug #1: Price stays $0.00
- Confirmed via accessibility snapshot: "Your Total $0.00" despite all selections
- Root cause: `updatePrice()` hardcodes `var total = 0` instead of summing parsed select values
- Saved: `/shared/screenshots/03-price-bug-zero-dollars.png`

### 7. Navigated to Checkout
- Clicked "Continue to Checkout" button via `eval`
- Checkout form displayed with 8 input fields

### 8. Filled checkout form
- Used `playwright-cli fill` for each field (with snapshot refresh between each due to ref staleness):
  - Full Name: Jane Doe
  - Email: jane@example.com
  - Address: 123 Rainey Street
  - City: Austin
  - Zip: ABCDE (intentionally invalid)
  - Card: 4242 4242 4242 4242
  - Expiry: 12/27
  - CVC: 123
- Saved: `/shared/screenshots/04-checkout-form-filled.png`

### 9. Submitted form and documented Bug #2
- Clicked "Place Order" via `eval`
- Observed via snapshot: "Invalid zip code format" error appeared
- All form field values were empty (confirmed by evaluating `.value` on all inputs — all returned `""`)
- Root cause in source (line 1076-1085): `submitOrder()` iterates all `#order-checkout input` and sets `.value = ''`, then calls `undefined.validate()` which throws TypeError
- Saved: `/shared/screenshots/05-checkout-form-cleared-bug.png`

## Deliverables

| File | Description |
|------|-------------|
| `/shared/screenshots/01-homepage.png` | Homepage |
| `/shared/screenshots/02-order-page-initial.png` | Order page before selections |
| `/shared/screenshots/03-price-bug-zero-dollars.png` | Bug #1: Price stuck at $0.00 |
| `/shared/screenshots/04-checkout-form-filled.png` | Checkout form filled before submit |
| `/shared/screenshots/05-checkout-form-cleared-bug.png` | Bug #2: Form cleared on validation error |
| `/shared/checkout-requirement.md` | Structured requirement document |
| `/shared/e2e-walkthrough-log.md` | This log |
