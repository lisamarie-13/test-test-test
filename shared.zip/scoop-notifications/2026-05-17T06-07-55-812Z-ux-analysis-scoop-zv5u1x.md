Now let me copy the files to `/shared/`:Analysis complete. Both files written:

- **`/shared/ux-analysis-report.md`** — Full ranked broken journey report
- **`/shared/ux-severity-scores.csv`** — Raw per-page severity data (30 URLs)

**Key findings:**

| Rank | Page | Severity | Priority |
|------|------|----------|----------|
| 1 | `/order/checkout` | 53.6 | Critical |
| 2 | `/order/build-your-own` | 37.4 | Critical |
| 3 | `/rewards/signup` | 34.2 | Critical |
| 4 | `/rewards/login` | 23.8 | High |
| 5-30 | All others | 8.7–10.2 | Medium |

**Two journeys dominate the problem space:**

1. **Order Journey** (combined severity 27.5, Critical) — Checkout is catastrophic: 72% bounce rate, 15% JS errors, 73% poor LCP (avg 5721ms), massive layout shift (CLS 0.451), and 69% negative Medallia sentiment. Top complaint is broken form submission. Build-your-own also suffers with 56% bounce, poor LCP, and layout shift.

2. **Rewards Journey** (combined severity 22.2, High) — Signup has 64% bounce, 11% errors, and 69% negative sentiment with users unable to submit the signup form. Login follows at 58% bounce and 10% errors with password/login complaints.

Everything else on the site is Medium-priority with healthy Core Web Vitals and ~29-34% bounce rates — a clear signal that the damage is concentrated in the transactional flows.