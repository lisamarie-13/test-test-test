Good, I can see the Order page with the Build Your Own form. Let me take screenshots and interact with the dropdowns.Confirmed: "Your Total $0.00" — the price bug is visible. Selections made but total stays at $0.00.Good, I'm on the checkout page. Now let me fill in all form fields.I can see the bug: "Invalid zip code format" error message appeared, and the form fields are cleared (placeholders showing instead of filled values — e.g., "you@email.com" instead of "jane@example.com", "78701" instead of "ABCDE", "MM/YY" instead of "12/27"). The Name field still shows "Jane Doe" as placeholder text.All fields are empty. The form was completely cleared on validation error.Now let me also check the JS source to document the technical details:Good, I have all the technical details. Now let me write the deliverables.Walkthrough complete. Here is a summary of what was done:

**Two bugs documented in the Order Checkout journey:**

**Bug #1 — Price Never Updates:** On the "Build Your Own Margarita" page, selecting options in the Base Spirit, Mixer, and Extras dropdowns has no effect on the price display — it always shows "$0.00". Root cause: `updatePrice()` hardcodes `var total = 0` instead of parsing and summing the select values.

**Bug #2 — Form Clears on Validation Error:** On the Checkout page, submitting with an invalid zip code (e.g., "ABCDE") triggers the validation error message, but simultaneously clears every form field. The user loses all entered data and must start over. Additionally, `undefined.validate()` throws a TypeError.

**Deliverables written:**
- 5 screenshots in `/shared/screenshots/` documenting each step and both bugs
- `/shared/checkout-requirement.md` — structured requirement with problem statement, impact metrics, steps to reproduce, technical details, and acceptance criteria
- `/shared/e2e-walkthrough-log.md` — detailed log of every action taken during the walkthrough