BROKEN JOURNEY ANALYSIS — Glitchcraft Margarita Labs
=======================================================
Data period: 2026-04-16 to 2026-05-15
OpTel events analyzed: 31,380 rows (3,138,000 weighted pageviews)
Medallia responses analyzed: 533

RANKED PAGES (by severity score)
-----------------------------------
1. /order/checkout — Critical
   Severity Score: 53.6
   Pageviews: 114,700
   Bounce: 71.7% | Errors: 15.4% | LCP: 5721ms (poor) | CLS: 0.451 (poor) | INP: 478ms (needs-improvement)
   Medallia: 148 responses | CSAT: 2.0/5 | Negative: 69% | 102 negative verbatims
   Top complaint: "form/submit broken"

2. /order/build-your-own — Critical
   Severity Score: 37.4
   Pageviews: 140,800
   Bounce: 55.8% | Errors: 7.0% | LCP: 4496ms (poor) | CLS: 0.351 (poor) | INP: 398ms (needs-improvement)
   Medallia: 81 responses | CSAT: 3.0/5 | Negative: 31% | 25 negative verbatims
   Top complaint: "error/crash"

3. /rewards/signup — Critical
   Severity Score: 34.2
   Pageviews: 65,100
   Bounce: 63.7% | Errors: 11.1% | LCP: 3470ms (needs-improvement) | CLS: 0.253 (poor) | INP: 325ms (needs-improvement)
   Medallia: 77 responses | CSAT: 1.9/5 | Negative: 69% | 53 negative verbatims
   Top complaint: "signup issues"

4. /rewards/login — High
   Severity Score: 23.8
   Pageviews: 76,100
   Bounce: 58.0% | Errors: 10.0% | LCP: 3126ms (needs-improvement) | CLS: 0.175 (needs-improvement) | INP: 326ms (needs-improvement)
   Medallia: 54 responses | CSAT: 2.9/5 | Negative: 39% | 21 negative verbatims
   Top complaint: "login issues"

5. /recipes/classic-lime — Medium
   Severity Score: 10.2
   Pageviews: 44,100
   Bounce: 33.6% | Errors: 0.7% | LCP: 1493ms (good) | CLS: 0.047 (good) | INP: 114ms (good)
   Medallia: No responses

6. /about — Medium
   Severity Score: 9.7
   Pageviews: 79,200
   Bounce: 30.8% | Errors: 1.9% | LCP: 1517ms (good) | CLS: 0.044 (good) | INP: 115ms (good)
   Medallia: No responses

7. /order/confirmation — Medium
   Severity Score: 9.7
   Pageviews: 49,100
   Bounce: 31.4% | Errors: 1.0% | LCP: 1478ms (good) | CLS: 0.045 (good) | INP: 116ms (good)
   Medallia: No responses

8. /order/party-packs — Medium
   Severity Score: 9.7
   Pageviews: 64,400
   Bounce: 31.7% | Errors: 0.6% | LCP: 1475ms (good) | CLS: 0.045 (good) | INP: 116ms (good)
   Medallia: No responses

9. /menu/frozen-strawberry-margarita — Medium
   Severity Score: 9.6
   Pageviews: 122,300
   Bounce: 31.4% | Errors: 0.7% | LCP: 1495ms (good) | CLS: 0.046 (good) | INP: 117ms (good)
   Medallia: No responses

10. /recipes — Medium
   Severity Score: 9.5
   Pageviews: 82,900
   Bounce: 31.1% | Errors: 0.7% | LCP: 1497ms (good) | CLS: 0.045 (good) | INP: 118ms (good)
   Medallia: 26 responses | CSAT: 4.2/5 | Negative: 0% | 0 negative verbatims

11. /menu/smoky-mezcal-margarita — Medium
   Severity Score: 9.5
   Pageviews: 98,400
   Bounce: 30.4% | Errors: 1.5% | LCP: 1507ms (good) | CLS: 0.044 (good) | INP: 113ms (good)
   Medallia: No responses

12. / — Medium
   Severity Score: 9.5
   Pageviews: 400,400
   Bounce: 30.9% | Errors: 0.9% | LCP: 1504ms (good) | CLS: 0.046 (good) | INP: 114ms (good)
   Medallia: 32 responses | CSAT: 4.0/5 | Negative: 0% | 0 negative verbatims

13. /blog/margarita-history — Medium
   Severity Score: 9.4
   Pageviews: 46,800
   Bounce: 30.6% | Errors: 1.1% | LCP: 1498ms (good) | CLS: 0.045 (good) | INP: 114ms (good)
   Medallia: No responses

14. /menu/spicy-mango-margarita — Medium
   Severity Score: 9.4
   Pageviews: 158,100
   Bounce: 30.4% | Errors: 1.2% | LCP: 1489ms (good) | CLS: 0.046 (good) | INP: 116ms (good)
   Medallia: No responses

15. /blog/best-tequilas-2026 — Medium
   Severity Score: 9.4
   Pageviews: 63,400
   Bounce: 30.4% | Errors: 1.1% | LCP: 1499ms (good) | CLS: 0.046 (good) | INP: 116ms (good)
   Medallia: No responses

16. /locations/seattle — Medium
   Severity Score: 9.4
   Pageviews: 67,100
   Bounce: 30.7% | Errors: 0.7% | LCP: 1505ms (good) | CLS: 0.043 (good) | INP: 115ms (good)
   Medallia: No responses

17. /order — Medium
   Severity Score: 9.3
   Pageviews: 244,600
   Bounce: 30.3% | Errors: 0.8% | LCP: 1486ms (good) | CLS: 0.046 (good) | INP: 115ms (good)
   Medallia: No responses

18. /menu/classic-margarita — Medium
   Severity Score: 9.2
   Pageviews: 190,100
   Bounce: 29.9% | Errors: 1.0% | LCP: 1509ms (good) | CLS: 0.044 (good) | INP: 114ms (good)
   Medallia: No responses

19. /faq — Medium
   Severity Score: 9.2
   Pageviews: 31,500
   Bounce: 29.5% | Errors: 1.3% | LCP: 1465ms (good) | CLS: 0.044 (good) | INP: 111ms (good)
   Medallia: No responses

20. /menu — Medium
   Severity Score: 9.1
   Pageviews: 324,700
   Bounce: 29.5% | Errors: 1.1% | LCP: 1489ms (good) | CLS: 0.045 (good) | INP: 114ms (good)
   Medallia: 33 responses | CSAT: 4.3/5 | Negative: 0% | 0 negative verbatims

21. /locations — Medium
   Severity Score: 9.1
   Pageviews: 128,600
   Bounce: 29.7% | Errors: 0.9% | LCP: 1485ms (good) | CLS: 0.045 (good) | INP: 114ms (good)
   Medallia: 38 responses | CSAT: 3.7/5 | Negative: 0% | 0 negative verbatims

22. /contact — Medium
   Severity Score: 9.0
   Pageviews: 50,100
   Bounce: 29.3% | Errors: 0.8% | LCP: 1465ms (good) | CLS: 0.046 (good) | INP: 117ms (good)
   Medallia: No responses

23. /catering — Medium
   Severity Score: 9.0
   Pageviews: 62,000
   Bounce: 28.7% | Errors: 1.5% | LCP: 1530ms (good) | CLS: 0.046 (good) | INP: 114ms (good)
   Medallia: 26 responses | CSAT: 4.0/5 | Negative: 0% | 0 negative verbatims

24. /menu/skinny-margarita — Medium
   Severity Score: 8.9
   Pageviews: 79,900
   Bounce: 28.5% | Errors: 1.5% | LCP: 1520ms (good) | CLS: 0.045 (good) | INP: 112ms (good)
   Medallia: No responses

25. /locations/austin — Medium
   Severity Score: 8.9
   Pageviews: 43,300
   Bounce: 28.6% | Errors: 1.2% | LCP: 1504ms (good) | CLS: 0.045 (good) | INP: 115ms (good)
   Medallia: No responses

26. /404 — Medium
   Severity Score: 8.8
   Pageviews: 34,200
   Bounce: 28.7% | Errors: 0.9% | LCP: 1524ms (good) | CLS: 0.045 (good) | INP: 115ms (good)
   Medallia: No responses

27. /locations/portland — Medium
   Severity Score: 8.8
   Pageviews: 48,500
   Bounce: 28.9% | Errors: 0.6% | LCP: 1487ms (good) | CLS: 0.044 (good) | INP: 118ms (good)
   Medallia: No responses

28. /blog — Medium
   Severity Score: 8.8
   Pageviews: 101,800
   Bounce: 28.3% | Errors: 1.1% | LCP: 1526ms (good) | CLS: 0.045 (good) | INP: 115ms (good)
   Medallia: 18 responses | CSAT: 4.2/5 | Negative: 0% | 0 negative verbatims

29. /rewards — Medium
   Severity Score: 8.7
   Pageviews: 93,700
   Bounce: 28.2% | Errors: 0.9% | LCP: 1526ms (good) | CLS: 0.045 (good) | INP: 117ms (good)
   Medallia: No responses

30. /catering/request-quote — Medium
   Severity Score: 8.7
   Pageviews: 32,100
   Bounce: 28.3% | Errors: 0.6% | LCP: 1586ms (good) | CLS: 0.045 (good) | INP: 113ms (good)
   Medallia: No responses

JOURNEY GROUPING
-----------------
1. Order Journey (/order, /order/build-your-own, /order/checkout, /order/confirmation) — Critical
   Combined severity: 27.5
   /order/checkout: high bounce (72%); errors (15%); slow LCP (5721ms); layout shift (CLS 0.451); slow interactions (INP 478ms); negative feedback (69%)
   /order/build-your-own: high bounce (56%); slow LCP (4496ms); layout shift (CLS 0.351); negative feedback (31%)

2. Rewards Journey (/rewards, /rewards/signup, /rewards/login) — High
   Combined severity: 22.2
   /rewards/signup: high bounce (64%); errors (11%); layout shift (CLS 0.253); negative feedback (69%)
   /rewards/login: high bounce (58%); negative feedback (39%)

3. /recipes/classic-lime (/recipes/classic-lime) — Medium
   Combined severity: 10.2
   No major issues detected

4. /about (/about) — Medium
   Combined severity: 9.7
   No major issues detected

5. /order/party-packs (/order/party-packs) — Medium
   Combined severity: 9.7
   No major issues detected

6. /menu/frozen-strawberry-margarita (/menu/frozen-strawberry-margarita) — Medium
   Combined severity: 9.6
   No major issues detected

7. /recipes (/recipes) — Medium
   Combined severity: 9.5
   No major issues detected

8. /menu/smoky-mezcal-margarita (/menu/smoky-mezcal-margarita) — Medium
   Combined severity: 9.5
   No major issues detected

9. / (/) — Medium
   Combined severity: 9.5
   No major issues detected

10. /blog/margarita-history (/blog/margarita-history) — Medium
   Combined severity: 9.4
   No major issues detected

11. /menu/spicy-mango-margarita (/menu/spicy-mango-margarita) — Medium
   Combined severity: 9.4
   No major issues detected

12. /blog/best-tequilas-2026 (/blog/best-tequilas-2026) — Medium
   Combined severity: 9.4
   No major issues detected

13. /locations/seattle (/locations/seattle) — Medium
   Combined severity: 9.4
   No major issues detected

14. /menu/classic-margarita (/menu/classic-margarita) — Medium
   Combined severity: 9.2
   No major issues detected

15. /faq (/faq) — Medium
   Combined severity: 9.2
   No major issues detected

16. /menu (/menu) — Medium
   Combined severity: 9.1
   No major issues detected

17. /locations (/locations) — Medium
   Combined severity: 9.1
   No major issues detected

18. /contact (/contact) — Medium
   Combined severity: 9.0
   No major issues detected

19. /catering (/catering) — Medium
   Combined severity: 9.0
   No major issues detected

20. /menu/skinny-margarita (/menu/skinny-margarita) — Medium
   Combined severity: 8.9
   No major issues detected

21. /locations/austin (/locations/austin) — Medium
   Combined severity: 8.9
   No major issues detected

22. /404 (/404) — Medium
   Combined severity: 8.8
   No major issues detected

23. /locations/portland (/locations/portland) — Medium
   Combined severity: 8.8
   No major issues detected

24. /blog (/blog) — Medium
   Combined severity: 8.8
   No major issues detected

25. /catering/request-quote (/catering/request-quote) — Medium
   Combined severity: 8.7
   No major issues detected

TOP RECOMMENDED JOURNEYS TO RECORD
--------------------------------------
1. Order Journey — critical severity (53.6); 15% JS errors; 72% bounce rate; poor LCP on 73% of views; 69% negative Medallia feedback; users report "form/submit broken"
2. Rewards Journey — critical severity (34.2); 11% JS errors; 64% bounce rate; 69% negative Medallia feedback; users report "signup issues"
3. /recipes/classic-lime — severity 10.2
4. /about — severity 9.7
5. /order/party-packs — severity 9.7
